#!/bin/bash

set -e

echo "#### TESTING eth0 ###"
ping -qc 4 100.10.2.12

echo ""

echo ""