#!/bin/bash

set -e

echo "#### TESTING eth0 ###"
ping -qc 4 100.30.1.30

echo ""

echo ""